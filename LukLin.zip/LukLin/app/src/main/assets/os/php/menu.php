<?php
require("./core.php");
if ($_GET["req"]==NULL) {
  $req = $_POST["req"];
} else {
  $req = $_GET["req"];
}

function PrivateID($type) {
    global $openDb;
    $query = "SELECT * FROM `Movies` WHERE `type`='$type'";
    $run = mysqli_query($openDb, $query);
    return $run->num_rows;

}
function exeQuery($id, $type) {
    global $openDb;
    $query = "SELECT * FROM `Movies` WHERE `type`='$type' AND `PrivateId`=$id";
    $run = mysqli_query($openDb, $query);
    $data = $run->fetch_assoc();
    return $data;
}
function WriteJsObjectForHomePage($type) {
    global $openDb;
    $succ = 0;
    $lasted = 0;
    $max = PrivateID($type);
    echo "var $type=[";
    for ($i = $max; $i > 0; $i--) {
        $data = exeQuery($i, $type);
        if (rand(0, 4) == 2 && $lasted != $data["code"]) {
            $succ++;
            $id = $data["id"];
            $lasted = $data["code"];
            $title = $data["title"];
            $size = $data["size"];
            $path = $data["path"];
            $episode = $data["episode"];
            $code = $data["code"];
            $dir = $data["dir"];
            $type = $data["type"];
            $thumb = $data["thumb"];
            $language = $data["language"];
            echo "
        {
          'id':$id,
          'title':'$title',
          'size':'$size',
          'path':'$path',
          'episode':'$episode',
          'code':'$code',
          'dir':'$dir',
          'type':'$type',
          'thumb':'$thumb',
          'language':'$language'
        },
        ";
            if ($succ == 25) {
                break;
            }//
        }
    }
    echo "];";
}
function SetPrivateId($type) {
    global$openDb;
    $query = "SELECT * FROM `Movies` WHERE `type`='$type'";
    $exe = mysqli_query($openDb, $query);
    $i = 0;
    while ($data = $exe->fetch_assoc()) {
        $i++;
        $id = $data["id"];
        $eq = "UPDATE `Movies` SET `PrivateId`=$i WHERE `id`=$id";
        mysqli_query($openDb, $eq);
    }
}
function SearchData($table, $key, $value) {
    global $openDb;
    $search = "SELECT * FROM `$table` WHERE `$key` LIKE '%$value%'";
    $exe = mysqli_query($openDb, $search);
    while ($data = $exe->fetch_assoc()) {
        $src = $data["thumb"];
        $id = $data["id"];
        $title = $data["title"];
        echo "<choice>
           <view onclick=\"window.open('http://0.0.0.0:8080/view.php?id=$id')\">
          <img src='$src'onerror='this.src=\"./os/icons/notfound.png\"'/>
          <code class='title'>$title</code>
         </view>
         </choice>";
    }
}
function UpdateData($tb,$key,$value,$id,$ivalue){
  global $openDb;
  $query = "UPDATE `$tb` SET `$key`='$value' WHERE `$id`='$ivalue'";
  mysqli_query($openDb,$query);
}
function UploadData($title, $episode, $dir, $c, $type, $lan) {
    $id = IdGenerate("Movies")+1;
    if ($c == NULL) {
        $code = $id;
    } else {
        $code = $c;
    }
    global $openDb;
    $thumb = "https://raw.githubusercontent.com/oxifo/io/main/$id.png";
    $privated = PrivateId("$type")+1;
    $cm = "INSERT INTO `Movies`(`id`, `title`, `size`, `path`, `episode`, `code`, `dir`, `type`, `thumb`, `language`, `PrivateId`) VALUES ($id,'$title','','','$episode','$code','$dir','$type','$thumb','$lan','$privated')";
    if (mysqli_query($openDb, $cm) == TRUE) {
        echo "Success UploadData";
    }
}
function MenuView(){
  ?>
  
  <MenuView class="MenuView">
    <style type="text/css">
      #logo{
        width:50%;
        display:block;
        margin:50px auto;
      }
      button{
        display:block;
        margin:16px auto;
        min-width:150px;
        background:white;
        color:black;
        border:none;
        box-shadow:0px 0px 3px #CCCCCC;
        border-radius:3px;
        padding:9px 30px;
        transition-duration:0.5s;
        outline:none;
      }
      poz{
        width:fit-content;
        display:block;
        margin:25px auto;
        height:auto;
        box-shadow:0px 0px 3px #CCCCCC;
        padding:15px 30px;
        border-radius:5px;
        padding:10px 30px;
      }
      button:hover{
        background:blue;
        color:white;
      }
      a{
        text-decoration:none;
        padding:5px;
        color:blue;
      }
      #share{
        width:55px;
        height:auto;
        display:block;
        margin:5px auto;
      }
      basic{
        padding:5px 30px;
        display:block;
        margin:5px auto;
        border:1px solid #CCC;
        width:fit-content;
        border-radius:10px;
      }
      hr{
        border:none;
        width:100%;
        background:#CCC;
        height:0.5px;
        margin:30px 0px;
      }
    </style>
    <img id="logo"src="./os/icons/logo.png"/>
    <poz onclick="Java.PozApp('http://poz.free.nf/')">
      <a>Login</a>
      OR
      <a>SignUp</a>
    </poz>
    <hr/>
    <basic>
    <button onclick="Java.DownloadList()">Watch OffLine</button>
    <button>Lastest Movies</button>
    </basic>
    <hr/>
    <basic>
      <button onclick="Java.CreditAgent()">Credit Agent</button>
     <button onclick="Java.share('http://pozapp.iblogger.org/')">Share App</button>
    </basic>

  </MenuView>
  <?
}
switch ($req) {
    case 'SQLToJs':
        WriteJsObjectForHomePage("drama");
        WriteJsObjectForHomePage("action");
        WriteJsObjectForHomePage("horror");
        WriteJsObjectForHomePage("animi");
        WriteJsObjectForHomePage("sci_fi");
        break;
    case 'SearchData':
        SearchData($_GET["tb"], $_GET["key"], $_GET["v"]);
        break;
    case 'UploadData':
        UploadData($_POST["title"],$_POST["episodes"],$_POST["dir"],$_POST["code"],$_POST["type"],$_POST["language"]);
      break;
    case 'UpdateData':
      UpdateData($_POST["table"],$_POST["key"],$_POST["value"],$_POST["id"],$_POST["ivalue"]);
      break;
    case 'MenuView':
       MenuView();
      break;
}
?>