<!doctype html>
<html>
  <body>
    <button id="i"></button>
    <script type="text/javascript">
    
    <?php
       $req=$_GET["size"];
       require("./os/php/core.php");
       $query ="SELECT * FROM `Movies` WHERE `id` >= $req";
       $exe = mysqli_query($openDb,$query);
       echo "var movieList=[";
       while($data=$exe->fetch_assoc()){
             $id=$data["id"];
             $title=$data["title"];
             $size=$data["size"];
             $path=$data["path"];
             $episode=$data["episode"];
             $code=$data["code"];
             $dir=$data["dir"];
             $type =$data["type"];
             $thumb =$data["thumb"];
             $language=$data["language"];
             $PrivateId=$data["PrivateId"];
             $relative=$data["episode"];
         echo "
         {
           id:'$id',
           title:'$title',
           size:'$size',
           path:'$path',
           episode:'$episode',
           code:'$code',
           dir:'$dir',
           type:'$type',
           thumb:'$thumb',
           language:'$language',
           relative:'$relative',
           PrivateId:'$PrivateId'
         },
         ";
       }
       echo("];");
    ?>
    for(var i =0;i<movieList.length;i++){
      var id=movieList[i].id;
      var title=movieList[i].title;
      var size =movieList[i].size;
      var path=movieList[i].path;
      var episode=movieList[i].episode;
      var code =movieList[i].code;
      var dir =movieList[i].dir;
      var type=movieList[i].type;
      var thumb =movieList[i].thumb;
      var language=movieList[i].language;
      var relative=movieList[i].relative;
      var itemID =movieList[i].PrivateId;
      Java.SQL("CREATE TABLE IF NOT EXISTS `Movies`(id text,title text,size text,path text,episode text,code text,dir text,type text,thumb text,language text,PrivateId text)");
      Java.SQL(`INSERT INTO \`Movies\` VALUES ('${id}','${title}','${size}','${path}','${episode}','${code}','${dir}','${type}','${thumb}','${language}','${itemID}')`);
      Java.notification("INSERT DATA",""+i,i);
      
    }
    </script>
  </body>
</html>
