package com.zpk.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.zpk.R;
import android.transition.*;
import android.view.*;
import android.*;
import java.io.*;
import android.webkit.*;
import android.widget.*;
import java.net.*;
import android.app.*;
import androidx.core.app.*;

public class LoadPage extends AppCore{
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
		Manifest(Manifest.permission.WRITE_EXTERNAL_STORAGE);
	    WebView w = new WebView(this);
		setContentView(w);
		w.setWebChromeClient(new WebChromeClient(){
			public void onProgressChanged(WebView v ,int rate){
				long[] vb = {1000};
				NotificationChannel c = new NotificationChannel("rate","rate",NotificationManager.IMPORTANCE_DEFAULT);
				NotificationManager manager =getSystemService(NotificationManager.class);
				NotificationCompat.Builder builder = new NotificationCompat.Builder(LoadPage.this,"");
				builder.setContentTitle("Prepare Downloading....");
				builder.setProgress(100,rate,true);
				builder.setSmallIcon(R.drawable.icon);
				builder.setVibrate(vb);
		        manager.createNotificationChannel(c);
				manager.notify(1,builder.build());
			}
		});
		BasicWebView(w,IntentData("E1"));
		}
		@JavascriptInterface
	    public String URLQuery(){
			try
			{
				URL openURL = new URL(IntentData("E1"));
				return openURL.getQuery().replace("q=","");
			}
			catch (MalformedURLException e)
			{
				return "";
			}
		}
}