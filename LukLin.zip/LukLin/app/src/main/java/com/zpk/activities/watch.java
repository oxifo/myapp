package com.zpk.activities;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.zpk.R;
import android.widget.*;
import androidx.core.app.*;
import android.*;
import android.content.pm.*;
import android.view.View.*;
import android.view.*;
import android.media.*;
import java.io.*;
import java.util.*;
import android.webkit.*;
import android.database.sqlite.*;
import android.database.*;
import android.graphics.*;

public class watch extends AppCore
{
	MediaPlayer audio;TextView subtitle;TextView tt;
	VideoView video;
    @Override
    protected void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
		setContentView(R.layout.watch);
		try{
		tt = findViewById(R.id.subtitle);
		tt.setBackgroundColor(Color.rgb(26, 33, 110));
		Bundle b = getIntent().getExtras();
		final String FileName =b.getString("fileName");
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		video = findViewById(R.id.v);
		this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		video.setVideoPath("/storage/emulated/0/Android/data/apk.luklin/movie/" + FileName);
		final MediaController mc = new MediaController(this);
		audio = new MediaPlayer();
		try
		{
			audio.setDataSource("/storage/emulated/0/Android/data/apk.luklin/MAudio/" + FileName);
			audio.prepare();
		}
		catch (Exception e)
		{}
		Thread thread =new Thread(){
			public void run()
			{
				while (!isInterrupted())
				{
					try
					{
						sleep(1000);
					}
					catch (InterruptedException e)
					{}
					if (video.getCurrentPosition() > audio.getCurrentPosition() + 1000 || video.getCurrentPosition() + 1000 < audio.getCurrentPosition())
					{
						audio.seekTo(video.getCurrentPosition());
					}
					runOnUiThread(new Runnable(){

							@Override
							public void run()
							{

								try
								{
									int vc =video.getCurrentPosition() / 1000;
									String ReadQuery ="SELECT * FROM `" + FileName + "` WHERE `point`='" + vc + "'";
									SQLiteDatabase sql =openOrCreateDatabase("LukLin", MODE_PRIVATE, null);
									Cursor c=sql.rawQuery(ReadQuery, null);
									c.moveToFirst();
									String data =c.getString(c.getColumnIndex("description"));
									tt.setPadding(10, 10, 10, 10);
									tt.setText(String.valueOf(data));

								}
								catch (Exception e)
								{

								}
							}
						});
				}
			}
		};
		thread.start();
		video.setOnClickListener(new OnClickListener(){
				public void onClick(View v)
				{
					mc.setMediaPlayer(video);
					mc.setAnchorView(video);
					mc.show(2000);
					if (video.isPlaying() == false)
					{
						video.start();
						audio.start();
					}
				}  
			});
		if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
		{
			ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
		}
		}catch(Exception e){
			Toast(e.toString());
		}
    }

	@Override
	public void onBackPressed()
	{
		audio.pause();
		super.onBackPressed();
	}
	@JavascriptInterface
	public String FileName()
	{
		Bundle b =getIntent().getExtras();
		return b.getString("fileName");
	}
	@JavascriptInterface
	public void MediaControls()
	{
		video.start();
		audio.start();
	}
	@JavascriptInterface 
	public void Toast(String data)
	{
		Toast toast =Toast.makeText(getApplicationContext(), "", 1000);
		toast.setText(data);
		toast.setDuration(2000);
		toast.show();
	}
}