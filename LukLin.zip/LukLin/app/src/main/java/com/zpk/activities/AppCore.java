package com.zpk.activities;
import androidx.appcompat.app.*;
import android.webkit.*;
import android.database.sqlite.*;
import android.database.sqlite.SQLiteDatabase.*;
import android.database.*;
import android.app.*;
import androidx.core.app.*;
import android.*;
import android.content.pm.*;
import java.net.*;
import java.io.*;
import android.webkit.CookieManager;
import android.widget.*;
import android.os.*;
import java.util.*;
import android.content.*;
import com.zpk.R;
import android.view.*;

public class AppCore extends AppCompatActivity
{
	String userAgent = "Mozilla/5.0 (Linux; Android 10; M2004J19C Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/87.0.4280.101 Mobile Safari/537.36";
	SQLiteDatabase openSQL;
	String database = "LukLinApp";
	final String dir= "/storage/emulated/0/Android/data/apk.luklin/";

        
		@JavascriptInterface
		public void SQL(String QUERY)
		{
			openSQL = openOrCreateDatabase(database, MODE_PRIVATE, null);
			openSQL.execSQL(QUERY);
			openSQL.close();
		}
		@JavascriptInterface
		public int ColumnSize(String Query){
			try{
				openSQL = openOrCreateDatabase(database, MODE_PRIVATE, null);
				Cursor c= openSQL.rawQuery(Query,null);
				return c.getCount();
			}catch(Exception e){
				return 0;
			}
		}
		@JavascriptInterface
		public String READ(String Query,String key)
		{
			try{
				openSQL = openOrCreateDatabase(database, MODE_PRIVATE, null);
				Cursor pointer = openSQL.rawQuery(Query, null);
				pointer.moveToFirst();
				return pointer.getString(pointer.getColumnIndex(key));
				
			}catch(Exception e){
				return null;
			}
	  }
	  @JavascriptInterface
	  public String ViewData(String Query){
		  try{
			  openSQL = openOrCreateDatabase(database, MODE_PRIVATE, null);
			  Cursor pointer = openSQL.rawQuery(Query, null);
			  pointer.moveToFirst();
			  return "{\"logo\":\""+index(pointer,"thumb")+"\",\"code\":\""+index(pointer,"code")+"\",\"episodes\":\""+index(pointer,"episodes")+"\",\"title\":\""+index(pointer,"title")+"\",\"dir\":\""+index(pointer,"dir")+"\"}";

		  }catch(Exception e){
			  return null;
		  }
	  }
	public void BasicWebView(WebView web, String url)
	{
		web.loadUrl(url);
		WebSettings setup = web.getSettings();
		setup.setDomStorageEnabled(true);
		setup.setAllowContentAccess(true);
		setup.setJavaScriptEnabled(true);
		setup.setUserAgentString(userAgent);
		setup.setLoadsImagesAutomatically(true);
		setup.setMediaPlaybackRequiresUserGesture(true);
		setup.setUseWideViewPort(true);
		web.clearHistory();
		setup.getAllowFileAccess();
		setup.getAllowFileAccessFromFileURLs();
		setup.setAllowUniversalAccessFromFileURLs(true);
		setup.setAllowFileAccess(true);
		setup.setAllowFileAccessFromFileURLs(true);
		web.clearCache(true);
		setup.setCacheMode(WebSettings.LOAD_NO_CACHE);
		web.addJavascriptInterface(this, "Java");
	}
	@JavascriptInterface
	public void Manifest(String Permission)
	{
		if (ActivityCompat.checkSelfPermission(this, Permission) != PackageManager.PERMISSION_GRANTED)
		{
			ActivityCompat.requestPermissions(this, new String[]{Permission}, 1);
		}
	}
	
	@JavascriptInterface
	public void FileOperation(final String openURL,final long startBytes,final String Folder,final String title,final int id)
	{
		Thread thread = new Thread(){
			public void run(){
				try
				{  
					URL url=new URL(openURL);    
					FileOutputStream fos = new FileOutputStream(dir+Folder+"/"+title,true);
					HttpURLConnection http =(HttpURLConnection) url.openConnection();
					http.setRequestProperty("Range","bytes="+startBytes+"-");
					http.setRequestMethod("GET");
					http.setRequestProperty("User-Agent",userAgent);
					http.setRequestProperty("cookie",CookieManager.getInstance().getCookie(openURL));
					long size = http.getContentLengthLong();
					http.connect();
					InputStream is = http.getInputStream();
					int data;
					int v =0;
					byte[] b = new byte[1025];
					while((data=is.read(b))!=-1){
						fos.write(b,0,data);
						notification(title,""+(FileLength(dir+Folder+"/"+title)/1000000)+"MB / "+(size/1000000)+"MB",id);
					}

					fos.close();
					is.close();

				}
				catch (Exception e)
				{
					FileWriter(e.toString(), "/storage/emulated/0/Android/t.txt");
				}
			}
		};
		thread.start();
		
	}
	
	@JavascriptInterface
	public void Toast(String data)
	{
		TextView v = new TextView(this);
		Toast t = new Toast(this);
		t.setDuration(10000);
		t.setView(v);
		t.setText(data);
		t.show();
	}
	
	@JavascriptInterface
	public void FileWriter(String data, String dir)
	{
		try
		{
			FileWriter f = new FileWriter(dir);
			f.write(data);
			f.close();
		}
		catch (Exception e)
		{
			try
			{
				FileWriter f = new FileWriter(dir);
				f.write(e.toString());
				f.close();
			}
			catch (Exception eb)
			{}

		}
	}
	
	@JavascriptInterface
	public long FileLength(String dir){
		try{
			File f = new File(dir);
			return f.length();
		}catch(Exception e){
			return 0;
		}
	}
	
	@JavascriptInterface
	public StringBuffer FileContent(String dir){
		StringBuffer bf = new StringBuffer();
		try
		{
			FileInputStream f = new FileInputStream(dir);
			int data;
			while((data=f.read())!=-1){
				bf.append((char)data);
			}
			f.close();
			return bf;
		}
		catch (Exception e)
		{
			return null;
	}
  }
  
  @JavascriptInterface
  public void notification(String title,String content,int id){
	 try{
		 NotificationChannel chennel = new NotificationChannel("n","n",NotificationManager.IMPORTANCE_DEFAULT);
		 NotificationCompat.Builder builder = new NotificationCompat.Builder(this,"n")
			 .setSmallIcon(R.drawable.icon)
			 .setContentTitle(title)
			 .setContentText(content)
			 .setPriority(NotificationCompat.PRIORITY_DEFAULT);
		 NotificationManager manager = (NotificationManager) getSystemService(NotificationManager.class);
		 manager.createNotificationChannel(chennel);
		 manager.notify(id,builder.build());
	 } catch(Exception e){
		 FileWriter(e.toString(),"/storage/emulated/0/Android/data.txt");
	 }
  }
	@JavascriptInterface
	public String SELECTALL(String query){
		try{
			StringBuffer data = new StringBuffer();
			openSQL = openOrCreateDatabase(database, MODE_PRIVATE, null);
			Cursor c= openSQL.rawQuery(query,null);
			while(c.moveToNext()){

				data.append("<view onclick=\"Java.LoadPage('file:///android_asset/view.html?q="+c.getString(c.getColumnIndex("id"))+"','')\"><img src='"+c.getString(c.getColumnIndex("thumb"))+"'onerror='this.src=\"./os/icons/notfound.png\"'/><code>"+c.getString(c.getColumnIndex("title"))+"</code></view>");
			}
			return data.toString();
		}catch(Exception e){
			return "No Match Data Found";
		}
	}
	@JavascriptInterface 
	public String IntentData(String key){
		Bundle b = getIntent().getExtras();
		return b.getString(key);
	}
	@JavascriptInterface
	public void LoadPage(String url,String extra){
		Intent load = new Intent(getApplicationContext(),LoadPage.class);
		load.putExtra("E2",extra);
		load.putExtra("E1",url);
		startActivity(load);
	}
  @JavascriptInterface
   public void WebCrossDownloader(final String url,final String seachIndex,final int point,final String folder,final String title){
	   try{
		   runOnUiThread(new Runnable(){

				   @Override
				   public void run()
				   {
					   WebView web = new WebView(getApplicationContext());
					   BasicWebView(web,url);
					   web.setWebChromeClient(new WebChromeClient(){
							   public void onProgressChanged(WebView v ,int rate){
								   notiWITHProgress(100,rate);
							   }
						   });
					   web.setWebViewClient(new WebViewClient(){
						 int load =0;
						   public void onLoadResource(WebView www,String url){
							   if(url.startsWith("https://p.bstarstatic.com/fe-lib/images/web/")){
								Toast.makeText(getApplicationContext(),"File not found",1).show();
							}
							if(url.startsWith(seachIndex)){
								load +=1;
								if(load==1 && url.startsWith("https://upos-bstar1-mirrorakam.akamaized.net")){
									FileOperation(url,FileLength(dir+"movie/"+title),"movie",title,load);
								}
								if(load==3 && url.startsWith("https://upos-bstar1-mirrorakam.akamaized.net")){
									FileOperation(url,FileLength(dir+"MAudio/"+title),"MAudio",title,load);
								}
								if(load==1&&folder.equals("movie")){
									FileOperation(url,FileLength(dir+"movie/"+title),"movie",title,load);
								}
							}
		
						 }
	
					   });
					  
				   }
				   
		   });
	   }catch(Exception e){
		   FileWriter(e.toString(),"/storage/emulated/999/LukLin/console.log");
		 }
   }
   public  String index(Cursor c,String k){
	   try{
		   return c.getString(c.getColumnIndex(k));
	   }catch(Exception e){
		   return "";
	   }
   }
   public void notiWITHProgress(int max,int current){
	   long[] v={1000};
	   NotificationChannel c = new NotificationChannel("rate","rate",NotificationManager.IMPORTANCE_DEFAULT);
	   NotificationManager manager =getSystemService(NotificationManager.class);
	   NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(),"rate")
		   .setContentTitle("Prepare Downloading....")
		   .setProgress(max,current,true)
		   .setVibrate(v)
		   .setSmallIcon(R.drawable.icon)
		   .setPriority(Notification.PRIORITY_DEFAULT);
	   manager.createNotificationChannel(c);
	   manager.notify(100,builder.build());
	   if(current>80){
		   manager.cancel(100);
	   }
   }
   @JavascriptInterface
   public String DownloadFile(String path){
	   StringBuffer body =new StringBuffer();
	   File file =new File(path);
	   File[] list = file.listFiles();
	   int size =list.length;
	   for(int i=0;i<size;i++){
		   String title =new File(list[i].toString()).getName();
		   body.append("<view onclick=\"Java.WatchMovie('"+title+"')\"><img src='file://"+dir+"thumb/"+title+"'onerror=\"this.src='./os/icons/notfound.png'\"/><title>"+title+"</title></view>");
	   }
	   return body.toString();
   }
   @JavascriptInterface
   public void WatchMovie(String fileName){
	   Intent intent =new Intent(getApplicationContext(),watch.class);
	   intent.putExtra("fileName",fileName);
	   startActivity(intent);
   }
   @JavascriptInterface
   public void LoadSQL(){
	   Thread t = new Thread(){
		   public void run(){
			   AsyncTask sync = new AsyncTask(){

				   @Override
				   protected Object doInBackground(Object[] p1)
				   {
					   runOnUiThread(new Runnable(){

							   @Override
							   public void run()
							   {
								   int s =ColumnSize("SELECT * FROM `Movies` WHERE 1");

								   notiWITHProgress(100,0);
								   WebView we = new WebView(getApplicationContext());
								   BasicWebView(we,"http://0.0.0.0:8080/install.php?size="+s);

							   }


						   });
					   return null;
				   };


			   };
			   sync.execute();
		   }
	   };
	   t.start();
   }
}