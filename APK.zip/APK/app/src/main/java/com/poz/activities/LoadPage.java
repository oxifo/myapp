package com.poz.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.poz.R;
import android.transition.*;
import android.view.*;
import android.*;
import java.io.*;
import android.webkit.*;
import android.widget.*;
import java.net.*;
import android.app.*;
import androidx.core.app.*;
import com.poz.activities.*;
import java.util.*;
import android.net.*;
import android.view.View.*;
import android.graphics.*;
import android.content.*;

public class LoadPage extends AppCore{
	WebView w;ImageView translate;
	int count=0;

	@Override
	public void onBackPressed()
	{
		if(w.canGoBack()){
			w.goBack();
		}else{
			super.onBackPressed();
		    this.finish();
		}
	}
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
		Manifest(Manifest.permission.WRITE_EXTERNAL_STORAGE);
		String path =IntentData("E1");
		if(path.startsWith("file:///android_asset/")){
		    w = new WebView(this);
			setContentView(w);
		}else{
			
				setContentView(R.layout.google_drive);
				w =(WebView)findViewById(R.id.webview);
				translate=findViewById(R.id.translate);
				translate.setOnClickListener(new OnClickListener(){

						@Override
						public void onClick(View p1)
						{
							LoadPage("http://mm.kesug.com/?title="+IntentData("E2"),"");
						}


			 });
			
	     }
		if(path.endsWith(".m3u8")){
			Intent intent =new Intent(getApplicationContext(),watch.class);
			intent.putExtra("path",path);
			startActivity(intent);
			//Toast.makeText(getApplicationContext(),path,1).show();
		}else{
		BasicWebView(w,path);
		}
		final earn e=new earn(this,"http://mm.kesug.com/show.php");
		//e.setCancelable(false);
		e.show();
		ConnectivityManager net = (ConnectivityManager)getSystemService(this.CONNECTIVITY_SERVICE);
		final NetworkInfo info = net.getActiveNetworkInfo();
		Timer t=new Timer();
		t.schedule(new TimerTask(){

				@Override
				public void run()
				{
					runOnUiThread(new Runnable(){

							@Override
							public void run()
							{
								if(info.isConnected()){
									try{
										if(count<10){
											count++;
											e.CloseADV().setText(count+"/10");
											e.CloseADV().setBackgroundDrawable(getDrawable(R.drawable.radius));
										}else{
											e.CloseADV().setText("close");
											e.close.setTextColor(Color.RED);
										}
									}catch(Exception e){
										notification("",e.toString(),1);
									}
								}
							}
							
						
					});
				}
		},1000,1000);
		e.CloseADV().setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					if(count>9){
						e.dismiss();
					}
				}
			});
		UPDATE();
		}
		@JavascriptInterface
	    public String URLQuery(){
			try
			{
				URL openURL = new URL(IntentData("E1"));
				return openURL.getQuery().replace("q=","");
			}
			catch (MalformedURLException e)
			{
				return "";
			}
		}
		
}