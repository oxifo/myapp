package com.poz.activities;
import android.app.Dialog;
import android.webkit.*;
import android.content.*;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.poz.R;
import android.widget.*;
import android.view.*;
public class earn extends Dialog
{
	TextView close;
	String url;
	Context c;
	public WebView web;
	Context body;
    public earn(Context c,String http){
		super(c);
		this.url=http;
		this.c=c;
	}
	@Override
	public void onBackPressed()
	{
		if(web.canGoBack()){
			web.goBack();
		}else{
			super.onBackPressed();
		}
	}
	@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.earn);
        web = findViewById(R.id.webView);
		close =findViewById(R.id.close);
		
		AppCore a = new AppCore();
		a.BasicWebView(web,url);
    }
	public TextView CloseADV(){
		return findViewById(R.id.close);
	}
}