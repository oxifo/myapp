package com.poz.activities;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.poz.R;
import android.widget.*;
import androidx.core.app.*;
import android.*;
import android.content.pm.*;
import android.view.View.*;
import android.view.*;
import android.media.*;
import java.io.*;
import java.util.*;
import android.webkit.*;
import android.database.sqlite.*;
import android.database.*;
import android.graphics.*;
import android.net.*;

public class watch extends AppCore
{
	MediaPlayer audio;TextView subtitle;TextView tt;
	VideoView video;
	int errorCode =0;
    @Override
    protected void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
		setContentView(R.layout.watch);
		try{
		tt = findViewById(R.id.subtitle);
		tt.setBackgroundColor(Color.rgb(26, 33, 110));
		Bundle b = getIntent().getExtras();
		final String FileName =b.getString("fileName");
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		video = findViewById(R.id.v);
		this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION, WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		View v =this.getWindow().getDecorView();
		v.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
	     String path =b.getString("path");
		 if(path!=null){
			 video.setVideoURI(Uri.parse(path));
		 }else{
			 video.setVideoPath("/storage/emulated/0/Download/apk.luklin/movie/" + FileName);
		 }
		 
		final MediaController mc = new MediaController(this);
		audio = new MediaPlayer();
		try
		{
			audio.setDataSource("/storage/emulated/0/Download/apk.luklin/MAudio/" + FileName);
			audio.prepare();
		}
		catch (Exception e)
		{}
			MediaPlayer.OnPreparedListener prepare =new MediaPlayer.OnPreparedListener(){

				@Override
				public void onPrepared(MediaPlayer p1)
				{
					video.setLayoutParams(new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
				}
				
			
		};
		Thread thread =new Thread(){
			public void run()
			{
				while (!isInterrupted())
				{
					try
					{
						sleep(1000);
					}
					catch (InterruptedException e)
					{}
					if (video.getCurrentPosition() > audio.getCurrentPosition() + 1000 || video.getCurrentPosition() + 1000 < audio.getCurrentPosition())
					{
						audio.seekTo(video.getCurrentPosition());
					}
					runOnUiThread(new Runnable(){

							@Override
							public void run()
							{
							  int ExtraSecond = READ_INT("SELECT * FROM `ExtraFunction` WHERE `title`='"+FileName+"'","extraSeconds");
								
							  int mili = READ_INT("SELECT * FROM `ExtraFunction` WHERE `title`='"+FileName+"'","milisecond");
                              int vtime =(int)Math.floor(video.getCurrentPosition()+(mili*ExtraSecond));
							  String position =hours(vtime).replace(".0","")+":"+minutes(vtime).replace(".0","")+":"+second(vtime).replace(".0","");
							  try
								{
									int vc =(int)Math.floor(video.getCurrentPosition() / 1000);
									String ReadQuery ="SELECT * FROM `" + FileName + "` WHERE `position`='" + position + "'";
									String text= READ(ReadQuery,"translate");
									if(text!=null){
									    errorCode=0;
										tt.setText(text);
										tt.setPadding(10, 10, 10, 10);
										tt.setTextColor(Color.RED);
										tt.setBackground(watch.this.getDrawable(R.drawable.radius));
									}else{
										errorCode++;
										if(errorCode>3){
											tt.setText("");
											tt.setPadding(0,0,0,0);
										}
									}
								}
								catch (Exception e){}
							}
						});
				}
			}
		};
		thread.start();
		video.setOnClickListener(new OnClickListener(){
				public void onClick(View v)
				{
					mc.setMediaPlayer(video);
					mc.setAnchorView(video);
					mc.show(2000);
					if (video.isPlaying() == false)
					{
						video.start();
						audio.start();
					}
				}  
			});
		if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
		{
			ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
		}
		}catch(Exception e){
			Toast(e.toString());
		}
    }

	@Override
	public void onBackPressed()
	{
		audio.pause();
		super.onBackPressed();
	}
	@JavascriptInterface
	public String FileName()
	{
		Bundle b =getIntent().getExtras();
		return b.getString("fileName");
	}
	@JavascriptInterface
	public void MediaControls()
	{
		video.start();
		audio.start();
	}
	@JavascriptInterface 
	public void Toast(String data)
	{
		Toast toast =Toast.makeText(getApplicationContext(), "", 1000);
		toast.setText(data);
		toast.setDuration(2000);
		toast.show();
	}
}