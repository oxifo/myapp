package com.poz.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.poz.R;
import android.transition.*;
import android.view.*;
import android.*;
import java.io.*;
import android.webkit.*;
import android.widget.*;
import java.net.*;
import android.app.*;
import androidx.core.app.*;
import com.poz.activities.*;
import java.util.*;
import android.net.*;
import android.view.View.*;

public class DownloadFiles extends AppCore{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

		getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
		Manifest(Manifest.permission.WRITE_EXTERNAL_STORAGE);
	    WebView w = new WebView(this);
		setContentView(w);
		BasicWebView(w,"file:///android_asset/DownloadList.html");
		UPDATE();
	}
	@JavascriptInterface
	public String URLQuery(){
		try
		{
			URL openURL = new URL(IntentData("E1"));
			return openURL.getQuery().replace("q=","");
		}
		catch (MalformedURLException e)
		{
			return "";
		}
	}

}