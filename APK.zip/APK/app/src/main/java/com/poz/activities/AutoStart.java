package com.poz.activities;
import android.content.*;
import java.io.*;
import android.os.*;
import android.widget.*;
public class AutoStart extends BroadcastReceiver
{

	@Override
	public void onReceive(Context p1, Intent intent)
	{
		switch(intent.getAction()){
			case intent.ACTION_BATTERY_CHANGED:Toast.makeText(p1,"",1000).show();
			break;
		}
	}
   
}